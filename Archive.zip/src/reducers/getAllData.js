import { 
  TOGGLE_TABLE_FILTER,
  REQUEST_TOGGLE_NORMALIZE,
  SUCCESS_TOGGLE_NORMALIZE,
} from '../actionTypes';

const row = {
  id: "",
  prescriberName: "Name",
  prescriberMSO: "Mso",
  prescriberPrimaryPractice: "Practice",
  prescriberPrimaryAddress: "Address",
  prescriberPrimaryCounty: "County",
  npiNumber: "Number",
  PrimarySpeciality: "Speciality",
  spendPerMember: 0,
  genericDispensingRate: 0,
  costPerScript: 0,
  extendedDaySuppleScriptPercentile: 0,
  nonFormularyFillsPercentile: 0,
  totalFills: 0,
  totalAllowed: 0,
  genericEfficiencyRate: 0,
  opioidFillsPercentile: 0,
  preferedBrandFills: 0,
  nonPreferredBrandFillsPercentils: 0,
  specialityFillsPercentile: 0,
  selectCareFillsPercentile: 0,
};

const rows = [];

for (let i = 0; i < 20; i++) {
  let data = { ...row };
  data.id = i;
  rows.push(data);
}

const initalState = {
  loading: false,
  error: null,
  headers: [
    { name: "prescriber Name", value: "prescriberName" },
    { name: "prescriber MSO ", value: "prescriberMSO" },
    { name: "prescriber Primary Practice", value: "prescriberPrimaryPractice" },
    { name: "prescriber Primary Address", value: "prescriberPrimaryAddress" },
    { name: "prescriber Primary County", value: "prescriberPrimaryCounty" },
    { name: "NPI Number", value: "npiNumber" },
    { name: "Primary Speciality", value: "PrimarySpeciality" },
    { name: "SpendPerMember", value: "spendPerMember" },
    { name: "GenericDispensingRate", value: "genericDispensingRate" },
    { name: "CostPerScript", value: "costPerScript" },
    { name: "ExtendedDaySuppleScriptPercentile", value: "extendedDaySuppleScriptPercentile" },
    { name: "NonFormularyFillsPercentile", value: "nonFormularyFillsPercentile" },
    { name: "TotalFills", value: "totalFills" },
    { name: "TotalAllowed", value: "totalAllowed" },
    { name: "GenericEfficiencyRate", value: "genericEfficiencyRate" },
  ],
  rows,
  maxPin: 5,
  maxCompare: 5,
  filterType: '',
  isDownload: false,
  normalize: false,
};

const getAllData = (state = initalState, action) => {
  const { type, payload } = action;
  switch (type) {
    case TOGGLE_TABLE_FILTER:
      return {
        ...state,
        filterType: payload.filterType,
        isDownload: payload.isDownload,
      }
    case REQUEST_TOGGLE_NORMALIZE:{
      return {
        ...state,
        loading: true,
      }}
      case SUCCESS_TOGGLE_NORMALIZE:{
        return {
          ...state,
          loading: false,
          rows: [...payload],
      }}
    default:
      return state;
  }
}

export default getAllData;