import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import './styles.css';
import * as Styles from '../../common/CustomTable/SharedStyles';

import {
  manageDays,
  manageSwitchData,
} from '../../actions/getAllData';

import PageHeader from './PageHeader';
import TableFilter from './TableFilter';
import Table from '../../common/CustomTable/table';
import Data from '../../sample';

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        return (
            <Fragment>
              {/* <PageHeader /> */}
                  <Table headers={Data.headers} rows={Data.rowsData} normalize={this.props.normalize === true} />
              {/* <TableFilter /> */}
            </Fragment>
        );
    }
}

const mapStateToProps = (state) => ({
  normalize: state.GetAllData.normalize,
  table: state.table,
})

const dispatchToProps = {
  manageDays,
  manageSwitchData,
}
 
export default connect(mapStateToProps, dispatchToProps)(Home);