import React from 'react';

const PageNotFound = () => (
    <div className="text-center h1 align-middle"><b>404,</b>This is not the web Page your are looking for</div>
);
 
export default PageNotFound;